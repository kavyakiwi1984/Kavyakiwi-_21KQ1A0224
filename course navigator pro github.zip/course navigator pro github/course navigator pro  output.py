Python 3.9.7 (tags/v3.9.7:1016ef3, Aug 30 2021, 20:19:38) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
======== RESTART: C:\Users\Bebu\OneDrive\Documents\python project\c4.py ========
Enter the number of courses: 20

Enter details for Course 1:
Enter course name: MAT LAb
Enter course fee: $1500
Enter number of enrolled students: 70
Enter total number of seats: 120
Enter course duration: 30 days

Enter details for Course 2:
Enter course name: ES
Enter course fee: $1200
Enter number of enrolled students: 40
Enter total number of seats: 100
Enter course duration: 30 days

Enter details for Course 3:
Enter course name: AI
Enter course fee: $1600
Enter number of enrolled students: 75
Enter total number of seats: 150
Enter course duration: 60 days

Enter details for Course 4:
Enter course name: DS
Enter course fee: $400
Enter number of enrolled students: 82
Enter total number of seats: 150
Enter course duration: 60 days

Enter details for Course 5:
Enter course name: IOT
Enter course fee: $700
Enter number of enrolled students: 50
Enter total number of seats: 100
Enter course duration: 15 days

Enter details for Course 6:
Enter course name: Cyber security
Enter course fee: $900
Enter number of enrolled students: 40
Enter total number of seats: 80
Enter course duration: 30 days

Enter details for Course 7:
Enter course name: Python
Enter course fee: $600
Enter number of enrolled students: 65
Enter total number of seats: 120
Enter course duration: 20 days

Enter details for Course 8:
Enter course name: Java
Enter course fee: $2000
Enter number of enrolled students: 40
Enter total number of seats: 120
Enter course duration: 60 days

Enter details for Course 9:
Enter course name: c++
Enter course fee: $500
Enter number of enrolled students: 35
Enter total number of seats: 80
Enter course duration: 30 days

Enter details for Course 10:
Enter course name: c programmin
Enter course fee: $900
Enter number of enrolled students: 100
Enter total number of seats: 200
Enter course duration: 30 days

Enter details for Course 11:
Enter course name: DBMS
Enter course fee: $1200
Enter number of enrolled students: 30
Enter total number of seats: 100
Enter course duration: 40 days

Enter details for Course 12:
Enter course name: Data structers
Enter course fee: $ 1200
Enter number of enrolled students: 60
Enter total number of seats: 120
Enter course duration: 25 days

Enter details for Course 13:
Enter course name: Auto CAD
Enter course fee: $1300
Enter number of enrolled students: 30
Enter total number of seats: 80
Enter course duration: 25 days

Enter details for Course 14:
Enter course name: EV
Enter course fee: $1600
Enter number of enrolled students: 40
Enter total number of seats: 80
Enter course duration: 60 days

Enter details for Course 15:
Enter course name: Ship design
Enter course fee: $800
Enter number of enrolled students: 30
Enter total number of seats: 60
Enter course duration: 10 days

Enter details for Course 16:
Enter course name: VL&SI
Enter course fee: $900
Enter number of enrolled students: 20
Enter total number of seats: 60
Enter course duration: 15 days

Enter details for Course 17:
Enter course name: MS
Enter course fee: $400
Enter number of enrolled students: 25
Enter total number of seats: 80
Enter course duration: 18 days

Enter details for Course 18:
Enter course name: Block chain technology
Enter course fee: $700
Enter number of enrolled students: 55
Enter total number of seats: 80
Enter course duration: 10 days

Enter details for Course 19:
Enter course name: java script
Enter course fee: $800
Enter number of enrolled students: 20
Enter total number of seats: 80
Enter course duration: 20 days

Enter details for Course 20:
Enter course name: HTML
Enter course fee: $1500
Enter number of enrolled students: 50
Enter total number of seats: 100
Enter course duration: 30 days

Course Details:

-------------------------------------------------------------------------------------------------
| Course Name               | Fee          | Enrolled Students    | Seats Left | Course Duration           |
-------------------------------------------------------------------------------------------------
| MAT LAb                   | $1500.00     | 70               | 50         | 30 days                   |
| ES                        | $1200.00     | 40               | 60         | 30 days                   |
| AI                        | $1600.00     | 75               | 75         | 60 days                   |
| DS                        | $400.00      | 82               | 68         | 60 days                   |
| IOT                       | $700.00      | 50               | 50         | 15 days                   |
| Cyber security            | $900.00      | 40               | 40         | 30 days                   |
| Python                    | $600.00      | 65               | 55         | 20 days                   |
| Java                      | $2000.00     | 40               | 80         | 60 days                   |
| c++                       | $500.00      | 35               | 45         | 30 days                   |
| c programmin              | $900.00      | 100              | 100        | 30 days                   |
| DBMS                      | $1200.00     | 30               | 70         | 40 days                   |
| Data structers            | $1200.00     | 60               | 60         | 25 days                   |
| Auto CAD                  | $1300.00     | 30               | 50         | 25 days                   |
| EV                        | $1600.00     | 40               | 40         | 60 days                   |
| Ship design               | $800.00      | 30               | 30         | 10 days                   |
| VL&SI                     | $900.00      | 20               | 40         | 15 days                   |
| MS                        | $400.00      | 25               | 55         | 18 days                   |
| Block chain technology    | $700.00      | 55               | 25         | 10 days                   |
| java script               | $800.00      | 20               | 60         | 20 days                   |
| HTML                      | $1500.00     | 50               | 50         | 30 days                   |
-------------------------------------------------------------------------------------------------

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 1
Enter the name of the course to display fee: Python
The fee for Python is $600.00

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 1
Enter the name of the course to display fee: Data structers
The fee for Data structers is $1200.00

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 1
Enter the name of the course to display fee: Cyber security
The fee for Cyber security is $900.00

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 2

Enrollment Details for Each Course:
MAT LAb: Enrolled students - 70, Seats left - 50
ES: Enrolled students - 40, Seats left - 60
AI: Enrolled students - 75, Seats left - 75
DS: Enrolled students - 82, Seats left - 68
IOT: Enrolled students - 50, Seats left - 50
Cyber security: Enrolled students - 40, Seats left - 40
Python: Enrolled students - 65, Seats left - 55
Java: Enrolled students - 40, Seats left - 80
c++: Enrolled students - 35, Seats left - 45
c programmin: Enrolled students - 100, Seats left - 100
DBMS: Enrolled students - 30, Seats left - 70
Data structers: Enrolled students - 60, Seats left - 60
Auto CAD: Enrolled students - 30, Seats left - 50
EV: Enrolled students - 40, Seats left - 40
Ship design: Enrolled students - 30, Seats left - 30
VL&SI: Enrolled students - 20, Seats left - 40
MS: Enrolled students - 25, Seats left - 55
Block chain technology: Enrolled students - 55, Seats left - 25
java script: Enrolled students - 20, Seats left - 60
HTML: Enrolled students - 50, Seats left - 50

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 8

Total Number of Courses: 20

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 9

Courses with Fee less than Than $1000:
Total Courses with Fee less than Than $1000: 11

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: DBMS
Invalid option. Please try again.

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 3
Enter the name of the course to display details: DBMS

Course Details:
Name: DBMS
Fee: $1200.00
Enrolled Students: 30
Seats Left: 70
Course Duration: 40 days

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 4
Enter the name of the course to check existence: chip design
The course 'chip design' does not exist.

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 4
Enter the name of the course to check existence: ship design
The course 'ship design' exists.

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 6

Total Filled Seats Across All Courses: 957

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 7

Courses with Fee Greater Than $1000:
Total Courses with Fee Greater Than $1000: 9

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 10

Total Number of Seats Across All Courses: 2060

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: 5

Courses with Intake Less Than 50 Seats:
Total Courses with Intake Less Than 50 Seats: 0

Enter '1' to query course fee, '2' to query available seats, '3' to display specific course details, '4' to check course existence, '5' for enrollment details,'6' total filled seats,'7' course fee >1000$,'8' total courses,'9' course fee <1000$, '10' total seats or 'q' to quit: q
Exiting program...
>>> 
